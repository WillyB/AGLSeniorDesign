<html>
<head>
<title>AGL Actors DB</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body bgcolor="#00000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<!-- Save for Web Slices (LogIn.psd) -->
<table width="1401" height="968" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
	<tr>
		<td colspan="10">
			<img src="images/LogIn_01.gif" width="1400" height="295" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="295" alt=""></td>
	</tr>
	<tr>
		<td rowspan="10">
			<img src="images/LogIn_02.gif" width="209" height="672" alt=""></td>
		<td rowspan="6">
			<img src="images/LogIn_03.gif" width="340" height="170" alt=""></td>
		<td colspan="8">
			<img src="images/LogIn_04.gif" width="851" height="39" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="39" alt=""></td>
	</tr>
	<tr>
		<td rowspan="9">
			<img src="images/LogIn_05.gif" width="185" height="633" alt=""></td>
	  <td width="174" height="51" colspan="2" rowspan="3" background="images/LogIn_06.gif">&nbsp;
	    <label for="email"></label>
	    <input name="email" type="text" id="email" style="color: #FFFFFF;border:none;background-color:transparent;"></td>
		<td width="178" height="51" colspan="3" rowspan="3" background="images/LogIn_07.gif">&nbsp;
		  <label for="Password"></label>
	    <input type="password" name="Password" id="Password" style="color: #FFFFFF;border:none;background-color:transparent;"></td>
		<td colspan="2">
			<img src="images/LogIn_08.gif" width="314" height="6" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td>
			<!-- <img src="images/LogIn_09.gif" width="66" height="37" alt=""> -->
            <input type="image" name="Log In" value="login" src="images/LogIn_09.gif" width="66" height="37"/></td>
		<td rowspan="8">
			<img src="images/LogIn_10.gif" width="248" height="627" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="37" alt=""></td>
	</tr>
	<tr>
		<td rowspan="2">
			<img src="images/LogIn_11.gif" width="66" height="38" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="8" alt=""></td>
	</tr>
	<tr>
		<td colspan="5">
			<img src="images/LogIn_12.gif" width="352" height="30" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="30" alt=""></td>
	</tr>
	<tr>
		<td rowspan="5">
			<img src="images/LogIn_13.gif" width="67" height="552" alt=""></td>
		<td width="351" height="50" colspan="5" background="images/LogIn_14.gif">&nbsp;
		  <label for="email2"></label>
	    <input type="text" name="email2" id="email2" style="color: #FFFFFF;border:none;background-color:transparent;"></td>
		<td>
			<img src="images/spacer.gif" width="1" height="50" alt=""></td>
	</tr>
	<tr>
		<td rowspan="4">
			<img src="images/LogIn_15.gif" width="340" height="502" alt=""></td>
		<td width="226" height="51" colspan="2" rowspan="3" background="images/LogIn_16.gif">&nbsp;
		  <label for="password2"></label>
	    <input type="password" name="password2" id="password2" style="color: #FFFFFF;border:none;background-color:transparent;"></td>
		<td colspan="3">
			<img src="images/LogIn_17.gif" width="125" height="6" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="6" alt=""></td>
	</tr>
	<tr>
		<td rowspan="3">
			<img src="images/LogIn_18.gif" width="11" height="496" alt=""></td>
		<td colspan="2">
			<!-- <img src="images/LogIn_19.gif" width="114" height="38" alt=""> -->
            <input type="image" name="Create Profile" value="createprofile" src="images/LogIn_19.gif" width="114" height="38"/>
            </td>
		<td>
			<img src="images/spacer.gif" width="1" height="38" alt=""></td>
	</tr>
	<tr>
		<td colspan="2" rowspan="2">
			<img src="images/LogIn_20.gif" width="114" height="458" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="7" alt=""></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="images/LogIn_21.gif" width="226" height="451" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="1" height="451" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/spacer.gif" width="209" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="340" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="185" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="67" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="107" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="119" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="11" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="48" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="66" height="1" alt=""></td>
		<td>
			<img src="images/spacer.gif" width="248" height="1" alt=""></td>
		<td></td>
	</tr>
</table>
<!-- End Save for Web Slices -->
</body>
</html>